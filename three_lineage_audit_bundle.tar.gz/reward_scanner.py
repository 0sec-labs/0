import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import json
import os
import re
from datetime import datetime, timezone

class RewardScannerEngine:
    def __init__(self, output_ledger="rewards_ledger.json"):
        self.output_ledger = output_ledger
        self.target_sources = [
            {
                "name": "CoinDesk Bitcoin RSS Feed", 
                "url": "https://www.coindesk.com/arc/outboundfeeds/rss/?outputType=xml"
            }
        ]
        self.keywords = ["bitcoin", "btc", "sats", "cold wallet", "treasure", "puzzle", "reward"]

    def fetch_rss_feed(self, source):
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        req = urllib.request.Request(source["url"], headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    return response.read()
        except Exception as e:
            print(f"[-] Error querying {source['name']}: {e}")
        return None

    def parse_xml_feed(self, xml_data):
        discovered_matches = []
        try:
            root = ET.fromstring(xml_data)
            items = root.findall(".//item")
            for item in items:
                title = item.find("title").text if item.find("title") is not None else ""
                description = item.find("description").text if item.find("description") is not None else ""
                link = item.find("link").text if item.find("link") is not None else ""
                
                combined_text = f"{title} {description}"
                matched_kw = []
                for kw in self.keywords:
                    if re.search(r'\b' + re.escape(kw) + r'\b', combined_text, re.IGNORECASE):
                        matched_kw.append(kw)
                
                if matched_kw:
                    discovered_matches.append({
                        "title": title,
                        "url": link,
                        "matched_keywords": matched_kw,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    })
        except Exception as e:
            print(f"[-] XML Parsing error: {e}")
        return discovered_matches

    def save_ledger(self, new_events):
        try:
            if os.path.exists(self.output_ledger):
                with open(self.output_ledger, "r") as f:
                    ledger = json.load(f)
            else:
                ledger = {"events": []}
        except json.JSONDecodeError:
            ledger = {"events": []}
            
        existing_count = len(ledger.get("events", []))
        ledger["events"].extend(new_events)
        total_count = len(ledger["events"])

        with open(self.output_ledger, "w") as f:
            json.dump(ledger, f, indent=4)
            
        print(f"[+] Ledger Updated:")
        print(f"  ├── Previous Total: {existing_count} entries")
        print(f"  ├── Newly Added:    {len(new_events)} entries")
        print(f"  └── Cumulative Total: {total_count} entries stored in {self.output_ledger}")

    def run_scan_cycle(self):
        print(f"[{datetime.now(timezone.utc).isoformat()}] 🔍 Starting public reward scan cycle...")
        all_events = []

        for source in self.target_sources:
            print(f"  ├── Polling: {source['name']}")
            xml_data = self.fetch_rss_feed(source)
            if xml_data:
                matches = self.parse_xml_feed(xml_data)
                if matches:
                    print(f"  └── [MATCH] Found {len(matches)} matching entries in {source['name']}!")
                    for m in matches:
                        print(f"       • [{', '.join(m['matched_keywords'])}] {m['title'][:60]}...")
                    all_events.extend(matches)
                else:
                    print(f"  └── [INFO] Feed polled successfully, no target keywords in current batch.")

        if all_events:
            self.save_ledger(all_events)
        else:
            print("[-] No matching reward vectors recorded in this cycle.")

if __name__ == "__main__":
    scanner = RewardScannerEngine()
    scanner.run_scan_cycle()
