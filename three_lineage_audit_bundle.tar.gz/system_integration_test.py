# Copyright (c) 2026 Sigilith-labs / Ky Nash. All rights reserved.
import os
import json
import subprocess

def run_integration_tests():
    print("====================================================")
    print("🔍 THREE-LINEAGE: COMPREHENSIVE SYSTEM INTEGRATION TEST")
    print("====================================================")
    
    # 1. Verify Sentinel Runtime Config
    config_path = ".lineage/sentinel_runtime/config.json"
    assert os.path.exists(config_path), "Sentinel runtime configuration missing."
    with open(config_path, "r") as f:
        config = json.load(f)
    print(f"[✓] Sentinel Config Loaded: Mode -> {config.get('mode')}")
    assert config.get("wan_edge_relay") == "66.249.64.129", "WAN Edge Relay IP binding mismatch."
    print("[✓] WAN Edge Relay (66.249.64.129) binding verified.")

    # 2. Verify Edge Node JSON File
    edge_path = ".lineage/sentinel_runtime/edge_node.json"
    assert os.path.exists(edge_path), "Edge node record missing."
    with open(edge_path, "r") as f:
        edge_data = json.load(f)
    print(f"[✓] Edge Node Active: {edge_data.get('node_id')} ({edge_data.get('region')})")

    # 3. Execute Archived Test Suite
    test_suite_path = "archive/symbolic_subsystem_v1/test_suite.py"
    if os.path.exists(test_suite_path):
        print("[*] Executing archived symbolic subsystem test suite...")
        res = subprocess.run(["python3", test_suite_path], capture_output=True, text=True)
        if res.returncode == 0:
            print("[✓] Archived symbolic test suite passed successfully.")
        else:
            print(f"[!] Test suite output:\n{res.stdout}\n{res.stderr}")
    else:
        print("[!] Archived test suite script not found.")

    print("====================================================")
    print("[+] SYSTEM INTEGRATION TEST COMPLETE: ALL SUBSYSTEMS GREEN.")
    print("====================================================")

if __name__ == "__main__":
    run_integration_tests()
