import urllib.request
import json

token = "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"
repo = "Sigilith/ditto-subnet"
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "Sigilith-Diagnostics/1.0"
}

url = f"https://api.github.com/repos/{repo}/contents/"
req = urllib.request.Request(url, headers=headers)

try:
    with urllib.request.urlopen(req) as resp:
        files = json.loads(resp.read().decode())
        print(f"[*] Root contents of {repo}:")
        for f in files:
            print(f"  ├── {f['name']} ({f['type']})")
except Exception as e:
    print(f"[-] Error fetching repo contents: {e}")
