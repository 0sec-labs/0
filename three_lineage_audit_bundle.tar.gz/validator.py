import ast
import re
import json
import time
from typing import List, Set

class RedTeamVerificationError(ValueError):
    """Custom exception raised when a payload fails pre-flight verification."""
    pass

class PayloadStructuralAnalyzer(ast.NodeVisitor):
    """
    Analyzes payload architecture to ensure structural integrity
    and prevent execution failures before staging.
    """
    def __init__(self):
        self.dynamic_vectors: Set[str] = {"eval", "exec", "globals", "locals", "getattr", "setattr", "compile"}
        self.detected_vectors: List[str] = []

    def visit_Call(self, node: ast.Call):
        if isinstance(node.func, ast.Name):
            if node.func.id in self.dynamic_vectors:
                self.detected_vectors.append(f"Dynamic call hook '{node.func.id}' found at line {node.lineno}")
        elif isinstance(node.func, ast.Attribute):
            if node.func.attr.startswith("__") and node.func.attr.endswith("__"):
                self.detected_vectors.append(f"Dunder attribute handle '.{node.func.attr}' found at line {node.lineno}")
        self.generic_visit(node)

class RedPreFlightValidator:
    def __init__(self, log_path="arena_eval_audit.jsonl"):
        self.prohibited_patterns = [
            re.compile(r"DROP\s+TABLE", re.IGNORECASE),
            re.compile(r"rm\s+-rf", re.IGNORECASE)
        ]
        self.max_payload_length = 2000
        self.log_path = log_path

    def _log_staging_telemetry(self, stage: str, status: str, assessment: str):
        """Logs payload evaluation metrics directly to the target environment ledger."""
        entry = {
            "timestamp": time.time(),
            "operational_phase": f"RED_TEAM_{stage}",
            "staging_status": status,
            "assessment_summary": assessment
        }
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

    def verify_text_payload(self, text_content: str) -> bool:
        """Ensures raw payload text adheres to string constraints prior to transmission."""
        if len(text_content) > self.max_payload_length:
            msg = f"Payload size ({len(text_content)} bytes) exceeds delivery buffer limits."
            self._log_staging_telemetry("TEXT_STAGING", "REJECTED", msg)
            raise RedTeamVerificationError(msg)
        
        for pattern in self.prohibited_patterns:
            if pattern.search(text_content):
                msg = f"Payload text matches restricted baseline signature: '{pattern.pattern}'"
                self._log_staging_telemetry("TEXT_STAGING", "REJECTED", msg)
                raise RedTeamVerificationError(msg)
                
        self._log_staging_telemetry("TEXT_STAGING", "READY", "Text payload verification clear.")
        return True

    def verify_script_ast(self, python_code: str) -> bool:
        """Parses script structure to audit execution nodes before staging delivery."""
        try:
            tree = ast.parse(python_code)
            analyzer = PayloadStructuralAnalyzer()
            analyzer.visit(tree)
            
            if analyzer.detected_vectors:
                vectors = " | ".join(analyzer.detected_vectors)
                self._log_staging_telemetry("SCRIPT_STAGING", "FLAGGED", vectors)
                print(f"📍 [RECON NOTICE] Payload utilizes dynamic properties: {vectors}")
            else:
                self._log_staging_telemetry("SCRIPT_STAGING", "READY", "Script logic structure uniform.")
            
            return True
        except SyntaxError as e:
            msg = f"Payload compilation error on line {e.lineno}: {e.msg}"
            self._log_staging_telemetry("SCRIPT_STAGING", "MALFORMED", msg)
            raise ValueError(msg)

if __name__ == "__main__":
    stager = RedPreFlightValidator()
    print("=== INITIALISING RED TEAM PRE-FLIGHT VERIFICATION MATRIX ===")

    # Test Case 1: Standard operation validation
    valid_payload = "print('Sigilith local validator active.')"
    print("\n📦 Verifying Baseline Script:")
    if stager.verify_script_ast(valid_payload):
        print("  [+] Status: READY FOR STAGING")

    # Test Case 2: Inspecting dynamic execution configurations
    dynamic_payload = "getattr(object, '__subclasses__')()"
    print("\n📦 Verifying Dynamic Operational Script:")
    if stager.verify_script_ast(dynamic_payload):
        print("  [+] Status: DESIGN COMPLEXITY FLAGGED / VERIFIED")

    print("\n================== MATRIX BENCHMARK COMPLETE ==================")
