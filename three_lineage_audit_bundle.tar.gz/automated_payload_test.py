import urllib.request
import socket
import time

class MultiPortSignatureProbe:
    def __init__(self):
        self.candidate_hosts = ["127.0.0.1", "0.0.0.0"]
        # Expand target scope to encompass all vectors found in previous recon loops
        self.target_ports = [80, 8545, 9090]
        self._discover_interfaces()

    def _discover_interfaces(self):
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            if local_ip and local_ip not in self.candidate_hosts:
                self.candidate_hosts.append(local_ip)
        except Exception:
            pass

    def execute_probe_sweep(self):
        print(f"📡 Team Red Signature Probe active across interfaces: {self.candidate_hosts}")
        print(f"🎯 Targeted ports matrix: {self.target_ports}")
        
        for port in self.target_ports:
            print(f"\n⚡ Scanning target vector layer: Port {port}")
            for host in self.candidate_hosts:
                url = f"http://{host}:{port}"
                
                # Use raw socket connect_ex for low-overhead, rapid handshake checks
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1.0)
                result = s.connect_ex((host, port))
                s.close()
                
                if result == 0:
                    print(f"  💥 [PORT ALIVE] Route verified open: {host}:{port}")
                    # Try basic header extraction if it's open
                    self._grab_basic_banner(host, port)
                else:
                    print(f"  ├── {host}:{port} -> Dropped (Connection Refused)")

    def _grab_basic_banner(self, host, port):
        url = f"http://{host}:{port}/"
        try:
            req = urllib.request.Request(url, method='GET')
            with urllib.request.urlopen(req, timeout=2) as response:
                print(f"      📥 Operational Signature: {response.info().get('Server', 'Unknown Daemon Type')}")
        except Exception as e:
            print(f"      ⚠️ Handshake established, but banner query failed: {e}")

if __name__ == "__main__":
    probe = MultiPortSignatureProbe()
    probe.execute_probe_sweep()
