import os

new_token = "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"

# Update or create .env
env_lines = []
if os.path.exists(".env"):
    with open(".env", "r") as f:
        for line in f:
            if "GITHUB_TOKEN" in line or "GH_TOKEN" in line:
                key = line.split("=")[0].strip()
                env_lines.append(f"{key}={new_token}\n")
            else:
                env_lines.append(line)
else:
    env_lines.append(f"GITHUB_TOKEN={new_token}\n")

# If GITHUB_TOKEN wasn't in the file, append it
if not any("GITHUB_TOKEN" in l for l in env_lines):
    env_lines.append(f"GITHUB_TOKEN={new_token}\n")

with open(".env", "w") as f:
    f.writelines(env_lines)

print("[+] Updated .env with the active GitHub token!")
