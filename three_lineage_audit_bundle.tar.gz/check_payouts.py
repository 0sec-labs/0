import os
import re

btc_pattern = re.compile(r'\b(bc1|[13])[a-km-zA-HJ-NP-Z1-9]{25,59}\b')
keywords = ['wallet', 'payout', 'btc', 'address', 'destination']

print("[*] Scanning local workspace files for payout configurations and wallet addresses...")
found = False

for root, dirs, files in os.walk('.'):
    if '.git' in root or '__pycache__' in root:
        continue
    for file in files:
        if file.endswith(('.py', '.json', '.env', '.yaml', '.yml', '.txt', '.conf')):
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    matches = btc_pattern.findall(content)
                    has_keyword = any(k in content.lower() for k in keywords)
                    if matches or has_keyword:
                        print(f"\n📁 File: {filepath}")
                        if matches:
                            print(f"  ├── Wallet/BTC Pattern Detected: {set(matches)}")
                        if has_keyword:
                            for line in content.splitlines():
                                if any(k in line.lower() for k in keywords):
                                    print(f"  ├── Match: {line.strip()}")
                                    found = True
            except Exception:
                pass

if not found:
    print("\n[+] Scan complete. Review files manually if configs are stored outside standard text formats.")
