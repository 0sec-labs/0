import urllib.request
import json

token = "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"
repo = "Sigilith/ditto-subnet"
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "Sigilith-Diagnostics/1.0"
}

url = f"https://api.github.com/repos/{repo}/actions/runs?per_page=3"
req = urllib.request.Request(url, headers=headers)

try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read().decode())
        print(f"[*] Recent Workflow Runs for {repo}:")
        for run in data.get("workflow_runs", []):
            print(f"  ├── Run ID: {run['id']}")
            print(f"  ├── Name: {run['name']}")
            print(f"  ├── Status: {run['status']} | Conclusion: {run['conclusion']}")
            print(f"  └── Logs URL: {run['html_url']}")
except Exception as e:
    print(f"[-] Error fetching workflow runs: {e}")
