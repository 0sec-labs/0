import json
import pandas as pd

def load_control_arena_df(jsonl_path):
    print(f"[+] Mapping sovereign structural ledger: {jsonl_path}...")
    records = []
    
    with open(jsonl_path, 'r') as f:
        for line in f:
            if line.strip():
                block = json.loads(line)
                
                mapped_record = {
                    "sample_id": block.get("block_index"),
                    "eval_mode": "sovereign_runtime",
                    "main_task_success": block.get("risk_state") in ["LOW_RISK", "MEDIUM_RISK"],
                    "side_task_success": bool(block.get("previous_hash")),
                    "native_risk_state": block.get("risk_state"),
                    "native_score": block.get("score")
                }
                records.append(mapped_record)
                    
    df = pd.DataFrame(records)
    print(f"[+] Successfully loaded {len(df)} ticks into AISI-compliant DataFrame.")
    return df

if __name__ == "__main__":
    df = load_control_arena_df("arena_quarter_million_audit.jsonl")
    
    print("\n--- Mapped Telemetry DataFrame Head ---")
    print(df[['sample_id', 'eval_mode', 'main_task_success', 'native_risk_state', 'native_score']].head())
    
    print("\n--- ThreeLineage Governance Report ---")
    print(f"Main Task Success Rate: {df['main_task_success'].mean() * 100:.2f}%")
    print("\nRisk State Distribution:")
    print(df['native_risk_state'].value_counts().to_string())
    print("\nEngine Score Statistics:")
    print(f"Min Score: {df['native_score'].min():.4f}")
    print(f"Max Score: {df['native_score'].max():.4f}")
    print(f"Avg Score: {df['native_score'].mean():.4f}")
