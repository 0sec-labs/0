import os

if os.path.exists(".env"):
    print("[+] Found .env file. Scanning keys...")
    with open(".env", "r") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                masked = value.strip()[:4] + "..." if len(value.strip()) > 4 else "too short"
                print(f"  ├── Key found: '{key.strip()}' (starts with: {masked}, length: {len(value.strip())})")
else:
    print("[-] No .env file found in current directory.")
