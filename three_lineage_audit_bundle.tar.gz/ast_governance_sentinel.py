import ast
import sys
import hashlib
import time

class GovernanceSentinel(ast.NodeVisitor):
    """
    AST Governance Sentinel: Enforces runtime containment boundaries 
    and inspects execution logic to prevent code drift and unauthorized logic paths.
    """
    def __init__(self, allowed_modules, allowed_calls):
        self.allowed_modules = allowed_modules
        self.allowed_calls = allowed_calls
        self.violations = []

    def visit_Import(self, node):
        for alias in node.names:
            if alias.name not in self.allowed_modules:
                self.violations.append(f"Unauthorized module import detected: {alias.name}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module and node.module not in self.allowed_modules:
            self.violations.append(f"Unauthorized import-from detected: {node.module}")
        self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
            if func_name in ["eval", "exec", "__import__"]:
                self.violations.append(f"Critical security violation: Restricted function '{func_name}' called.")
        self.generic_visit(node)

def audit_target_script(filepath):
    print(f"==================================================")
    print(f" [AST SENTINEL] Auditing execution boundary: {filepath}")
    print(f"==================================================")
    
    # Define strict boundary rules (No drifting outside permitted scope)
    allowed_modules = {"json", "time", "sys", "ast", "hashlib", "urllib"}
    allowed_calls = {"print", "open", "json.dump", "json.load"}
    
    try:
        with open(filepath, "r") as f:
            source_code = f.read()
            
        # Compute structural hash for drift detection
        code_hash = hashlib.sha256(source_code.encode('utf-8')).hexdigest()
        print(f" [+] Baseline AST Hash : {code_hash[:16]}...")
        
        tree = ast.parse(source_code, filename=filepath)
        sentinel = GovernanceSentinel(allowed_modules, allowed_calls)
        sentinel.visit(tree)
        
        if sentinel.violations:
            print(" [!] GOVERNANCE BREACH DETECTED:")
            for v in sentinel.violations:
                print(f"      • {v}")
            print(" [x] Execution halted due to drift / policy violation.")
            sys.exit(1)
        else:
            print(" [✓] AST Structure Verified: Zero drift or policy violations.")
            print(" [✓] Runtime container boundary secure.")
            print("==================================================")
            
    except Exception as e:
        print(f" [!] Audit error encountered: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Self-audit the governance sentinel or a target script
    audit_target_script("ast_governance_sentinel.py")
