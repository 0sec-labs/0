import tarfile
import glob
import os
import json
import time

print("==================================================================")
print("  PACKAGING SECURITY AUDIT ARTIFACTS FOR SUBMISSION               ")
print("==================================================================")

# Gather all generated reports and scripts
artifacts = glob.glob("*.json") + glob.glob("*.py")
bundle_name = "three_lineage_audit_bundle.tar.gz"

manifest = {
    "timestamp": time.time(),
    "auditor": "Sigilith-labs",
    "target_protocols": ["Usual", "Uniswap v4", "LayerZero", "Wormhole"],
    "included_artifacts": artifacts,
    "status": "READY_FOR_SUBMISSION"
}

with open("submission_manifest.json", "w") as f:
    json.dump(manifest, f, indent=4)

artifacts.append("submission_manifest.json")

with tarfile.open(bundle_name, "w:gz") as tar:
    for artifact in artifacts:
        if os.path.exists(artifact):
            tar.add(artifact)
            print(f" [+] Added to bundle: {artifact}")

print("\n==================================================================")
print(f" Audit bundle successfully created: {bundle_name}")
print(" Submission manifest generated: submission_manifest.json")
print("==================================================================")
