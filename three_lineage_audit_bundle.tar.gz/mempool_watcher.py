import urllib.request
import json
from datetime import datetime, timezone

class MempoolWatcher:
    def __init__(self):
        # Public mempool API endpoint for tracking waiting/unconfirmed Bitcoin transactions
        self.endpoint = "https://mempool.space/api/mempool/recent"

    def check_pending_payments(self):
        print(f"[{datetime.now(timezone.utc).isoformat()}] 🔄 Checking mempool for pending/waiting payments...")
        headers = {"User-Agent": "Sigilith-Agent/1.0"}
        req = urllib.request.Request(self.endpoint, headers=headers)
        
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    print(f"[+] Retrieved {len(data)} pending transactions waiting in mempool.")
                    
                    # Display top 3 waiting transactions as a sample
                    for idx, tx in enumerate(data[:3]):
                        txid = tx.get("txid", "unknown")
                        value_sats = tx.get("value", 0)
                        fee = tx.get("fee", 0)
                        print(f"  [{idx+1}] TXID: {txid[:16]}... | Value: {value_sats} sats | Fee: {fee} sats")
                    return data
        except Exception as e:
            print(f"[-] Error fetching mempool data: {e}")
        return []

if __name__ == "__main__":
    watcher = MempoolWatcher()
    watcher.check_pending_payments()
