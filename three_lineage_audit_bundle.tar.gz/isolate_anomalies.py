import json
import pandas as pd

def extract_high_risk_ticks(jsonl_path):
    print(f"[+] Scanning {jsonl_path} for HIGH_RISK circuit-breaker events...")
    anomalies = []
    
    with open(jsonl_path, 'r') as f:
        for line in f:
            if line.strip():
                block = json.loads(line)
                if block.get("risk_state") == "HIGH_RISK":
                    anomalies.append(block)
                    
    return pd.DataFrame(anomalies)

if __name__ == "__main__":
    anomalies_df = extract_high_risk_ticks("arena_quarter_million_audit.jsonl")
    print(f"\n[+] Isolated {len(anomalies_df)} HIGH_RISK anomaly ticks:")
    
    if not anomalies_df.empty:
        print(anomalies_df[['block_index', 'timestamp', 'score', 'previous_hash']].to_string())
        
        # Export isolated forensic report
        anomalies_df.to_json("high_risk_forensic_report.jsonl", orient="records", lines=True)
        print("\n[+] Exported anomaly logs to 'high_risk_forensic_report.jsonl'")
