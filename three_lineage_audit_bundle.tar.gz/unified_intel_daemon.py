import urllib.request
import json
import os
import xml.etree.ElementTree as ET
import re
from datetime import datetime, timezone

class UnifiedIntelDaemon:
    def __init__(self, reward_ledger="rewards_ledger.json", mempool_ledger="mempool_ledger.json"):
        self.reward_ledger = reward_ledger
        self.mempool_ledger = mempool_ledger
        
        self.rss_sources = [
            {
                "name": "CoinDesk Bitcoin RSS Feed", 
                "url": "https://www.coindesk.com/arc/outboundfeeds/rss/?outputType=xml"
            }
        ]
        self.mempool_endpoint = "https://mempool.space/api/mempool/recent"
        self.keywords = ["bitcoin", "btc", "sats", "cold wallet", "treasure", "puzzle", "reward"]

    def fetch_url(self, url, is_json=False):
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    raw = response.read().decode('utf-8')
                    return json.loads(raw) if is_json else raw
        except Exception as e:
            print(f"[-] Error querying {url}: {e}")
        return None

    def scan_rewards(self):
        print("\n🔍 [1/2] Scanning Public Reward Feeds...")
        new_matches = []
        for source in self.rss_sources:
            xml_data = self.fetch_url(source["url"])
            if xml_data:
                try:
                    root = ET.fromstring(xml_data)
                    for item in root.findall(".//item"):
                        title = item.find("title").text if item.find("title") is not None else ""
                        desc = item.find("description").text if item.find("description") is not None else ""
                        link = item.find("link").text if item.find("link") is not None else ""
                        
                        combined = f"{title} {desc}"
                        matched_kw = [kw for kw in self.keywords if re.search(r'\b' + re.escape(kw) + r'\b', combined, re.IGNORECASE)]
                        
                        if matched_kw:
                            new_matches.append({
                                "title": title,
                                "url": link,
                                "matched_keywords": matched_kw,
                                "timestamp": datetime.now(timezone.utc).isoformat()
                            })
                except Exception as e:
                    print(f"[-] XML Parse Error: {e}")
        return new_matches

    def scan_mempool(self):
        print("\n🔄 [2/2] Polling Mempool for Waiting Payments...")
        data = self.fetch_url(self.mempool_endpoint, is_json=True)
        pending_txs = []
        if data:
            for tx in data:
                pending_txs.append({
                    "txid": tx.get("txid", ""),
                    "value_sats": tx.get("value", 0),
                    "fee_sats": tx.get("fee", 0),
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
        return pending_txs

    def update_ledger(self, filepath, new_items, unique_key):
        try:
            if os.path.exists(filepath):
                with open(filepath, "r") as f:
                    ledger = json.load(f)
            else:
                ledger = {"events": []}
        except json.JSONDecodeError:
            ledger = {"events": []}

        existing_items = ledger.get("events", [])
        
        # De-duplication based on unique key (e.g., 'url' for articles or 'txid' for transactions)
        existing_keys = {item.get(unique_key) for item in existing_items}
        truly_new = [item for item in new_items if item.get(unique_key) not in existing_keys]

        prev_total = len(existing_items)
        existing_items.extend(truly_new)
        ledger["events"] = existing_items

        with open(filepath, "w") as f:
            json.dump(ledger, f, indent=4)

        return prev_total, len(truly_new), len(existing_items)

    def execute_cycle(self):
        print(f"==================================================")
        print(f"⚡ UNIFIED INTEL DAEMON CYCLE START: {datetime.now(timezone.utc).isoformat()}")
        print(f"==================================================")

        # 1. Run Reward Scan
        raw_rewards = self.scan_rewards()
        r_prev, r_added, r_total = self.update_ledger(self.reward_ledger, raw_rewards, unique_key="url")

        # 2. Run Mempool Scan
        raw_mempool = self.scan_mempool()
        m_prev, m_added, m_total = self.update_ledger(self.mempool_ledger, raw_mempool, unique_key="txid")

        # 3. Output Figures Summary
        print(f"\n📊 AGGREGATED METRICS SUMMARY:")
        print(f"  ├── [Reward Trackers Ledger]")
        print(f"  │    ├── Previous Stored: {r_prev}")
        print(f"  │    ├── Newly Appended:  {r_added}")
        print(f"  │    └── Cumulative Total: {r_total} entries")
        print(f"  └── [Mempool Transactions Ledger]")
        print(f"       ├── Previous Stored: {m_prev}")
        print(f"       ├── Newly Appended:  {m_added}")
        print(f"       └── Cumulative Total: {m_total} entries")
        print(f"==================================================")

if __name__ == "__main__":
    daemon = UnifiedIntelDaemon()
    daemon.execute_cycle()
