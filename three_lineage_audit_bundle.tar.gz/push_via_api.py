import urllib.request
import json
import base64

def create_branch_and_push():
    token = "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"
    repo = "Sigilith/traceguard-core"
    path = "solution_1262_v2.py"
    new_branch = "traceguard-patch-issue-1262"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "Sigilith-API-Pusher/1.0"
    }

    print("[*] Step 1: Getting main branch reference SHA...")
    ref_url = f"https://api.github.com/repos/{repo}/git/ref/heads/main"
    req = urllib.request.Request(ref_url, headers=headers)
    
    try:
        with urllib.request.urlopen(req) as resp:
            ref_data = json.loads(resp.read().decode())
            main_sha = ref_data["object"]["sha"]
            print(f"[+] Found main SHA: {main_sha}")
    except Exception as e:
        print(f"[-] Failed to get main branch SHA: {e}")
        return

    print("[*] Step 2: Creating branch 'traceguard-patch-issue-1262'...")
    create_ref_url = f"https://api.github.com/repos/{repo}/git/refs"
    ref_payload = {
        "ref": f"refs/heads/{new_branch}",
        "sha": main_sha
    }
    req = urllib.request.Request(create_ref_url, data=json.dumps(ref_payload).encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req) as resp:
            print(f"[+] Branch '{new_branch}' created successfully!")
    except Exception as e:
        # Branch might already exist, which is fine
        print(f"[*] Note on branch creation (may already exist): {e}")

    print("[*] Step 3: Uploading solution_1262_v2.py to the branch...")
    contents_url = f"https://api.github.com/repos/{repo}/contents/{path}"
    with open(path, "rb") as f:
        file_content = base64.b64encode(f.read()).decode("utf-8")

    payload = {
        "message": "Fix #1262: Implement deadline-aware and provider-resilient settlement validation",
        "content": file_content,
        "branch": new_branch
    }

    req = urllib.request.Request(contents_url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="PUT")
    try:
        with urllib.request.urlopen(req) as resp:
            if resp.status in [200, 201]:
                print(f"[+] Successfully pushed {path} to branch '{new_branch}' via GitHub API!")
            else:
                print(f"[-] Unexpected response status: {resp.status}")
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        print(f"[-] API Push Error (HTTP {e.code}): {error_body}")
    except Exception as e:
        print(f"[-] API Push Error: {e}")

if __name__ == "__main__":
    create_branch_and_push()
