import os
import glob

def scan_for_tokens():
    print("[*] Scanning workspace files for potential GitHub tokens or Discord config files...")
    
    # Search common file types and names
    patterns = ["*discord*", "*.env*", "*.json", "*.txt", "*.conf"]
    files_to_check = []
    for pattern in patterns:
        files_to_check.extend(glob.glob(pattern))
    
    # Also check current directory files
    for root, dirs, files in os.walk("."):
        if ".git" in dirs:
            dirs.remove(".git")
        for file in files:
            filepath = os.path.join(root, file)
            if filepath not in files_to_check:
                files_to_check.append(filepath)

    token_found = None
    for filepath in files_to_check:
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                # Look for token patterns or common prefixes
                if "ghp_" in content or "github_pat_" in content or "discord" in content.lower():
                    print(f"  ├── Found relevant markers in: {filepath}")
                    lines = content.splitlines()
                    for line in lines:
                        if "token" in line.lower() or "ghp_" in line or "github_pat_" in line:
                            print(f"       Line match: {line[:30]}...")
        except Exception:
            pass

scan_for_tokens()
