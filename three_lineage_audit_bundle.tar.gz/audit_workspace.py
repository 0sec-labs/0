import json
import glob
import os

print("==================================================================")
print("  THREE-LINEAGE-CORE: WORKSPACE AUDIT & REPORT SUMMARY            ")
print("==================================================================")

py_files = glob.glob("*.py")
json_files = glob.glob("*.json")

print(f"\n[+] Found {len(py_files)} Python scripts:")
for f in sorted(py_files):
    print(f"    - {f}")

print(f"\n[+] Found {len(json_files)} JSON report artifacts:")
for f in sorted(json_files):
    print(f"    - {f}")

print("\n==================================================================")
print("  INSPECTING REPORT CONTENTS:")
print("==================================================================")

for f in sorted(json_files):
    print(f"\n------------------------------------------------------------------")
    print(f" FILE: {f}")
    print(f"------------------------------------------------------------------")
    try:
        with open(f, "r") as file:
            data = json.load(file)
            print(json.dumps(data, indent=4))
    except Exception as e:
        print(f" [!] Error reading {f}: {e}")

print("\n==================================================================")
print("  WORKSPACE AUDIT COMPLETE")
print("==================================================================")
