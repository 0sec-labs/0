import ast
import time
import json
from enum import Enum

class AgentState(Enum):
    IDLE = 1
    SCANNING = 2
    ANALYZING = 3
    REPORTING = 4

class SecurityVisitor(ast.NodeVisitor):
    """AST Engine: Inspects structure without executing code."""
    def __init__(self):
        self.violations = []

    def visit_Import(self, node):
        for alias in node.names:
            if alias.name in ["os", "subprocess", "socket"]:
                self.violations.append(f"Forbidden Import: '{alias.name}' at line {node.lineno}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module in ["os", "subprocess", "socket"]:
            self.violations.append(f"Forbidden From-Import: 'from {node.module}' at line {node.lineno}")
        self.generic_visit(node)

class GovernanceEngine:
    def __init__(self):
        self.current_state = AgentState.IDLE
        self.observation_only = True  # Strict passive configuration boundary
        self.telemetry_log = []

    def transition_to(self, next_state: AgentState):
        """FSM Engine: Governs strict state changes."""
        print(f"🔄 FSM State Transition: {self.current_state.name} ──> {next_state.name}")
        self.current_state = next_state

    def verify_ast_safety(self, test_code: str) -> bool:
        """Evaluates security layer rules against static code input."""
        try:
            tree = ast.parse(test_code)
            visitor = SecurityVisitor()
            visitor.visit(tree)
            
            if visitor.violations:
                print(f"🛑 [CONTAINMENT BREACH] AST Policy Violations Detected:")
                for error in visitor.violations:
                    print(f"   └── {error}")
                return False
            return True
        except SyntaxError as e:
            print(f"❌ [SYNTAX ERROR] Unable to compile code tree: {e}")
            return False

    def capture_telemetry(self):
        """Simulates read-only data normalization."""
        metric_frame = {
            "timestamp": time.time(),
            "rpc_sync": True,
            "boundary_locked": self.observation_only,
            "violations_halted": 0
        }
        self.telemetry_log.append(metric_frame)
        print(f"📡 [TELEMETRY] Logged frame at {time.strftime('%H:%M:%S')}")

    def run(self, code_payload: str):
        """Executes the full agent validation life cycle loop."""
        print("====== STARTING AUTONOMOUS GOVERNANCE PIPELINE ======")
        
        # 1. State: IDLE -> SCANNING
        self.transition_to(AgentState.SCANNING)
        self.capture_telemetry()
        
        # 2. State: SCANNING -> ANALYZING
        self.transition_to(AgentState.ANALYZING)
        print(f"🔎 Inspecting script allocation payload via abstract syntax matching...")
        is_safe = self.verify_ast_safety(code_payload)
        
        # 3. State: ANALYZING -> REPORTING
        self.transition_to(AgentState.REPORTING)
        if is_safe:
            print("✅ [METRIC STATUS] Validation clean. Framework remains within allowed boundaries.")
            if not self.observation_only:
                # This segment is bypassed completely by the isolation wall
                print("Running active operational pipelines...")
                pass
            else:
                print("🔒 [PASSIVE SHIELD] Skipping deployment execution layer (Read-Only Matrix).")
        else:
            print("❌ [METRIC STATUS] Pipeline execution aborted due to security risk thresholds.")
            
        # 4. Return to IDLE
        self.transition_to(AgentState.IDLE)
        print("================== PIPELINE COMPLETE ==================\n")

# --- Direct Integration Test Execution ---
if __name__ == "__main__":
    engine = GovernanceEngine()

    # Test Scenario 1: Malicious payload targeting system calls
    untrusted_code = """
import os
import json
print("Initializing runtime tracking...")
# [SCRUBBED] os.system('echo Triggering payload...')
"""
    print("🧪 RUNNING RUNTIME ANALYSIS - SCENARIO 1 (UNTRUSTED CODE):")
    engine.run(untrusted_code)

    # Test Scenario 2: Clean, compliant payload
    compliant_code = """
import json
import math
print("Calculating metric hashes...")
data = json.dumps({'status': 'nominal', 'nodes': 4})
"""
    print("🧪 RUNNING RUNTIME ANALYSIS - SCENARIO 2 (COMPLIANT CODE):")
    engine.run(compliant_code)

