import urllib.request
import json
import os
from datetime import datetime, timezone

class GitHubPulseChecker:
    def __init__(self, target_repos):
        # target_repos = ["owner/repo_name", ...]
        self.target_repos = target_repos
        self.headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "Sigilith-GitPulseBot/1.0"
        }
        # Optional: If you have a GitHub Personal Access Token, set it in environment variables
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            self.headers["Authorization"] = f"Bearer {token}"

    def check_repository(self, repo):
        print(f"\n🔍 Auditing Repository: {repo}")
        
        # 1. Check Pull Requests
        pr_url = f"https://api.github.com/repos/{repo}/pulls?state=open"
        issues_url = f"https://api.github.com/repos/{repo}/issues?state=open"
        forks_url = f"https://api.github.com/repos/{repo}/forks"

        try:
            # Pull Requests
            req = urllib.request.Request(pr_url, headers=self.headers)
            with urllib.request.urlopen(req, timeout=5) as resp:
                prs = json.loads(resp.read().decode())
                print(f"  ├── Open Pull Requests: {len(prs)}")
                for pr in prs[:3]:
                    print(f"  │    • PR #{pr['number']}: {pr['title']} (by {pr['user']['login']})")

            # Issues (GitHub treats issues separately from PRs in the issues endpoint)
            req = urllib.request.Request(issues_url, headers=self.headers)
            with urllib.request.urlopen(req, timeout=5) as resp:
                all_issues = json.loads(resp.read().decode())
                # Filter out items that are actually pull requests
                true_issues = [i for i in all_issues if "pull_request" not in i]
                print(f"  ├── Open Issues: {len(true_issues)}")
                for issue in true_issues[:3]:
                    print(f"  │    • Issue #{issue['number']}: {issue['title']} (by {issue['user']['login']})")

            # Forks
            req = urllib.request.Request(forks_url, headers=self.headers)
            with urllib.request.urlopen(req, timeout=5) as resp:
                forks = json.loads(resp.read().decode())
                print(f"  └── Total Forks: {len(forks)}")

        except Exception as e:
            print(f"  [-] Error querying GitHub API for {repo}: {e}")

    def run_pulse(self):
        print(f"==================================================")
        print(f"⚡ GITHUB PULSE CHECK INITIALIZED: {datetime.now(timezone.utc).isoformat()}")
        print(f"==================================================")
        for repo in self.target_repos:
            self.check_repository(repo)
        print(f"\n==================================================")

if __name__ == "__main__":
    # Add your specific GitHub repositories here (e.g., your microG forks or custom projects)
    repos_to_monitor = [
        "microg/GmsCore",
        "vllm-project/vllm-omni"
    ]
    checker = GitHubPulseChecker(repos_to_monitor)
    checker.run_pulse()
