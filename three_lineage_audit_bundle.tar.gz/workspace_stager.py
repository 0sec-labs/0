import ast
import glob
import os
import json
import time
import shutil

class RedPreFlightValidator:
    def __init__(self, log_path="arena_eval_audit.jsonl"):
        self.log_path = log_path
        # Define staging targets
        self.passive_dir = "staging_passive"
        self.functional_dir = "staging_functional"

    def _setup_directories(self):
        """Ensures the clean target isolation directories exist."""
        for directory in [self.passive_dir, self.functional_dir]:
            if not os.path.exists(directory):
                os.makedirs(directory)

    def audit_and_stage(self):
        """Maps capabilities and cleanly distributes scripts based on profile."""
        self._setup_directories()
        py_files = glob.glob("*.py")
        
        # Prevent the tool from moving itself or its clones
        ignore_list = ["workspace_stager.py", "unified_agent.py", "validator.py"]
        py_files = [f for f in py_files if f not in ignore_list]

        if not py_files:
            print("📁 [RECON] No standalone scripts found to organize.")
            return

        print(f"📁 [RECON] Processing and staging {len(py_files)} files...\n")
        print(f"{'FILENAME':<35} | {'STAGING STATUS':<20} | {'STAGED LOCATION'}")
        print("-" * 90)

        for file_path in py_files:
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                tree = ast.parse(content)
                capabilities = []

                for node in ast.walk(tree):
                    if isinstance(node, ast.Import) or isinstance(node, ast.ImportFrom):
                        mods = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module]
                        for m in mods:
                            if m in ["socket", "urllib", "requests", "http"]:
                                capabilities.append("NETWORK_VECTOR")
                    
                    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "open":
                        capabilities.append("FILE_I/O_CONTROLLER")
                    
                    if isinstance(node, ast.Attribute) and node.attr in ["system", "Popen", "run", "subprocess"]:
                        capabilities.append("OS_EXECUTION_INTERFACE")

                # Determine destination folder
                if capabilities:
                    dest_folder = self.functional_dir
                    status = "READY / FUNCTIONAL"
                else:
                    dest_folder = self.passive_dir
                    status = "READY / PASSIVE"

                # Copy file into target isolated directory path safely
                shutil.copy2(file_path, os.path.join(dest_folder, file_path))
                print(f"{file_path:<35} | {status:<20} | ./{dest_folder}/")

            except (SyntaxError, Exception):
                print(f"{file_path:<35} | {'SKIPPED / ERROR':<20} | Verification Failure")

if __name__ == "__main__":
    print("=== INITIALISING RED TEAM AUTOMATED STAGING DEPLOYER ===")
    stager = RedPreFlightValidator()
    stager.audit_and_stage()
    print("==================== STAGING COMPLETE ====================")
