import subprocess
import re
import socket
import urllib.request
import json
import threading
from enum import Enum

class AgentState(Enum):
    IDLE = 1
    SCANNING = 2
    ANALYZING = 3
    INTERACTING = 4
    REPORTING = 5

class RealWorldRedTeamScanner:
    def __init__(self, target_ports=[22, 80, 8545, 9090, 9100]):
        self.target_ports = target_ports
        self.discovered_targets = []
        self.local_subnets = []

    def identify_active_subnets(self):
        """Senses active IP subnets configured on the device."""
        print("🔎 Identifying live network interfaces and VPN tunnels...")
        try:
            result = subprocess.run(["ip", "route"], capture_output=True, text=True, check=True)
            for line in result.stdout.splitlines():
                if "proto kernel" in line or "scope link" in line:
                    match = re.search(r"(\d+\.\d+\.\d+\.\d+/\d+)", line)
                    if match and not match.group(1).startswith("127."):
                        if match.group(1) not in self.local_subnets:
                            self.local_subnets.append(match.group(1))
        except Exception:
            pass
        
        if not self.local_subnets:
            self.local_subnets.append("192.168.1.0/24")
        
        print(f"📡 Detected Active Operation Subnets: {self.local_subnets}")

    def scan_single_host_port(self, host, port):
        """Handshakes a raw TCP socket to check if a port is open."""
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.3)
        try:
            result = s.connect_ex((host, port))
            if result == 0:
                print(f"💥 [TARGET ALIVE] Found open service at {host}:{port}")
                self.discovered_targets.append({"host": host, "port": port})
        except Exception:
            pass
        finally:
            s.close()

    def execute_network_sweep(self):
        """Performs a multithreaded network discovery sweep."""
        self.identify_active_subnets()
        threads = []
        
        for subnet in self.local_subnets:
            base_match = re.match(r"(\d+\.\d+\.\d+\.)", subnet)
            if not base_match:
                continue
            base_ip = base_match.group(1)
            
            print(f"🚀 Running multithreaded sweep across range: {base_ip}1-254 for ports {self.target_ports}...")
            for host_id in range(1, 255):
                target_host = f"{base_ip}{host_id}"
                for port in self.target_ports:
                    t = threading.Thread(target=self.scan_single_host_port, args=(target_host, port))
                    threads.append(t)
                    t.start()
                    
                    if len(threads) >= 64:
                        for th in threads:
                            th.join()
                        threads = []
                        
        for th in threads:
            th.join()

class AutonomousActiveEngine:
    def __init__(self):
        self.current_state = AgentState.IDLE

    def transition(self, next_state: AgentState):
        print(f"[FSM] {self.current_state.name} ──> {next_state.name}")
        self.current_state = next_state

    def interact_with_http_target(self, host, port):
        """Active Layer: Queries Port 80 to extract server software metadata descriptions."""
        url = f"http://{host}:{port}/"
        print(f"📡 [ACTIVE OUTBOUND] Querying server fingerprint headers via HTTP: {url}")
        try:
            req = urllib.request.Request(url, method='GET')
            with urllib.request.urlopen(req, timeout=3) as response:
                print(f"📥 [INTERACTION SUCCESS] Remote Server Response Metadata:")
                headers = response.info()
                for key, val in headers.items():
                    if key.lower() in ["server", "content-type", "date", "x-powered-by"]:
                        print(f"   └── {key}: {val}")
        except Exception as e:
            print(f"⚠️  Could not retrieve complete headers from {host}:{port}: {e}")

    def execute_pipeline(self):
        print("\n=== INITIALISING LIVE NETWORK DISCOVERY RECON UNIT ===")
        
        # 1. SCANNING STATE
        self.transition(AgentState.SCANNING)
        scanner = RealWorldRedTeamScanner()
        scanner.execute_network_sweep()
        
        # 2. ANALYZING STATE
        self.transition(AgentState.ANALYZING)
        print(f"\n👀 RECON COMPLETE. Discovered {len(scanner.discovered_targets)} active target vectors.")
        
        # 3. INTERACTING STATE
        self.transition(AgentState.INTERACTING)
        if scanner.discovered_targets:
            for target in scanner.discovered_targets:
                if target["port"] == 80:
                    self.interact_with_http_target(target["host"], target["port"])
                else:
                    print(f"📌 Logging discovery target: {target['host']}:{target['port']} (No interaction playbook ready)")
        else:
            print("⚠️ Scan concluded. No open server ports detected across network segments.")

        # 4. REPORTING STATE
        self.transition(AgentState.REPORTING)
        print("\n📊 [ACTIVE RUN COMPLETE] Framework return mapping synchronized.")

        # 5. IDLE STATE
        self.transition(AgentState.IDLE)
        print("===================== STANDBY =====================\n")

if __name__ == "__main__":
    engine = AutonomousActiveEngine()
    engine.execute_pipeline()
