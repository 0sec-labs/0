import os

evm_address = "0x58d30dc1759f78b3ffd98460c025000de7d218bc"
config_path = "payout_config.json"

import json
config = {
    "payout_network": "EVM / Coinbase Compatible",
    "destination_address": evm_address,
    "status": "Active"
}

with open(config_path, "w") as f:
    json.dump(config, f, indent=4)

print(f"[+] Payout configuration saved successfully to {config_path}")
print(f"    Target Address: {evm_address}")
