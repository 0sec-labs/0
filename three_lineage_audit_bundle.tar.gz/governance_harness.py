import ast
import json
import os
import sys
from datetime import datetime, timezone

class AutonomousGovernanceEngine:
    def __init__(self, ledger_path="agent_error_ledger.json"):
        self.ledger_path = ledger_path
        self.load_ledger()
        
        # Whitelist or policy rules for AST governance
        self.allowed_modules = {"ast", "json", "os", "sys", "re", "math", "asyncio"}
        self.forbidden_calls = {"os.system", "subprocess.Popen", "eval", "exec"}

    def load_ledger(self):
        if os.path.exists(self.ledger_path):
            with open(self.ledger_path, "r") as f:
                try:
                    self.ledger = json.load(f)
                except json.JSONDecodeError:
                    self.ledger = {"failures": []}
        else:
            self.ledger = {"failures": []}

    def log_failure(self, task_name, error_message):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "task": task_name,
            "error": error_message
        }
        self.ledger["failures"].append(entry)
        with open(self.ledger_path, "w") as f:
            json.dump(self.ledger, f, indent=4)
        print(f"[-] Ledger Updated: Logged failure for '{task_name}'")

    def validate_ast(self, python_code: str) -> bool:
        """Performs static AST analysis to enforce runtime containment."""
        try:
            tree = ast.parse(python_code)
        except SyntaxError as e:
            raise ValueError(f"AST Syntax Error: {e}")

        for node in ast.walk(tree):
            # Check for forbidden imports
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name not in self.allowed_modules:
                        raise ValueError(f"Policy Violation: Import of '{alias.name}' is unauthorized.")
            elif isinstance(node, ast.ImportFrom):
                if node.module and node.module not in self.allowed_modules:
                    raise ValueError(f"Policy Violation: Import from '{node.module}' is unauthorized.")
            
            # Check for forbidden function executions
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Attribute):
                    val_name = getattr(node.func.value, 'id', '')
                    attr_name = node.func.attr
                    full_call = f"{val_name}.{attr_name}"
                    if full_call in self.forbidden_calls:
                        raise ValueError(f"Policy Violation: Execution call '{full_call}' is blocked.")

        return True

    def simulate_local_build(self, python_code: str, task_name: str) -> bool:
        """Pre-flight check: Validates AST and simulates execution safely."""
        print(f"\n[+] Running Pre-Flight Governance Check for: {task_name}")
        try:
            # Step 1: AST Validation
            self.validate_ast(python_code)
            print("[✓] AST Governance Check: PASSED")

            # Step 2: Sandbox Compilation Test
            compile(python_code, '<string>', 'exec')
            print("[✓] Local Compilation Test: PASSED")
            
            return True
        except Exception as e:
            print(f"[-] Governance Check FAILED: {e}")
            self.log_failure(task_name, str(e))
            return False

# --- Testing the Governance Engine ---
if __name__ == "__main__":
    engine = AutonomousGovernanceEngine()

    safe_code = """
import json
import math

def calculate_metric(x):
    return math.sqrt(x) * 2
"""

    unsafe_code = """
import os
# [SCRUBBED] os.system('echo "Unauthorized execution"')
"""

    print("=== TEST 1: Safe Code Evaluation ===")
    success = engine.simulate_local_build(safe_code, "Task_Calculate_Metric")
    
    print("\n=== TEST 2: Unsafe Code Evaluation ===")
    success_unsafe = engine.simulate_local_build(unsafe_code, "Task_System_Probe")
