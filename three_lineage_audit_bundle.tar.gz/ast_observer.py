import ast
import os
import glob

class SecurityVisitor(ast.NodeVisitor):
    def __init__(self, filename):
        self.filename = filename
        self.violations = []

    def visit_Import(self, node):
        for alias in node.names:
            if alias.name in ["os", "subprocess", "socket"]:
                self.violations.append(f"Standard Import -> '{alias.name}' at line {node.lineno}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module in ["os", "subprocess", "socket"]:
            self.violations.append(f"From Import -> 'from {node.module} import ...' at line {node.lineno}")
        self.generic_visit(node)

class RogueASTObserver:
    def __init__(self):
        self.observation_only = True  # Strict passive-only enforcement
        print("[Rogue-Observer] AST Scan Mode Active. Inspection only, no code execution.\n")

    def inspect_workspace(self):
        """Scans all Python files in the current repository directory."""
        py_files = glob.glob("*.py")
        
        if not py_files:
            print("No Python files detected in the target directory loop.")
            return

        print(f"🔎 Scanning {len(py_files)} files for hazardous system imports...\n")
        
        for file_path in py_files:
            # Prevent the scanner from trapping its own execution profile
            if file_path == "ast_observer.py":
                continue

            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    code_content = f.read()

                # Build the AST representation safely
                tree = ast.parse(code_content)
                visitor = SecurityVisitor(file_path)
                visitor.visit(tree)

                # Report Findings without modifying or running the files
                if visitor.violations:
                    print(f"⚠️  [RISK ENCOUNTERED] File: {file_path}")
                    for violation in visitor.violations:
                        print(f"   └── {violation}")
                else:
                    print(f"✅ [CLEAN] File: {file_path} contains no forbidden standard OS vectors.")

            except SyntaxError as e:
                print(f"❌ [SYNTAX ERROR] Could not compile AST tree for {file_path}: {e}")
            except Exception as e:
                print(f"❌ [ERROR] Reading {file_path}: {e}")

        print("\n🏁 Workspace scan complete. Status: Standby. Zero payloads evaluated.")

if __name__ == "__main__":
    observer = RogueASTObserver()
    observer.inspect_workspace()

