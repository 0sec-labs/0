import urllib.request
import json
import base64

def push_solution():
    token = "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"
    repo = "Sigilith/ditto-subnet"
    path = "solution_2044.py"
    branch = "main"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "Sigilith-API-Pusher/1.0"
    }

    with open("solution_2044.py", "rb") as f:
        file_content = base64.b64encode(f.read()).decode("utf-8")

    url = f"https://api.github.com/repos/{repo}/contents/{path}"
    sha = None
    try:
        req = urllib.request.Request(f"{url}?ref={branch}", headers=headers)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode())
            sha = data.get("sha")
    except Exception:
        pass

    payload = {
        "message": "Fix #2044: Implement full treasury decision matrix, custody controls, and threat model",
        "content": file_content,
        "branch": branch
    }
    if sha:
        payload["sha"] = sha

    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="PUT")
    try:
        with urllib.request.urlopen(req) as resp:
            if resp.status in [200, 201]:
                print(f"[+] Successfully pushed full implementation of {path} to {repo}!")
            else:
                print(f"[-] Unexpected response status: {resp.status}")
    except urllib.error.HTTPError as e:
        print(f"[-] API Error (HTTP {e.code}): {e.read().decode()}")

if __name__ == "__main__":
    push_solution()
