import os
import subprocess

def run_git_cmd(cmd):
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"Error: {e.stderr.strip()}"

def map_git():
    print("[*] Mapping Git version control across workspace pipelines...")
    
    # Target directories or files to track
    targets = ['.', './workers', './staging_functional']
    
    for target in targets:
        if os.path.exists(target):
            os.chdir(target if target != '.' else '.')
            # Check if git is initialized
            if not os.path.exists('.git'):
                print(f"  ├── Initializing Git repository in {target}")
                run_git_cmd(['git', 'init'])
            
            # Stage audit files and configs
            run_git_cmd(['git', 'add', 'megasweep_audit.json', 'payout_config.json'])
            status = run_git_cmd(['git', 'status', '--short'])
            if status:
                print(f"  ├── Staged changes in {target}:\n{status}")
            else:
                print(f"  ├── Pipeline {target} is clean and fully mapped.")
            os.chdir(os.path.expanduser('~/three-lineage-core'))

    print("[+] Git pipeline mapping complete.")

if __name__ == "__main__":
    map_git()
