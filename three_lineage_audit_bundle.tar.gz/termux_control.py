# -*- coding: utf-8 -*-
import re
import os
import glob
import socket
import sys
import time

class TeamRedSuite:
    def __init__(self):
        self.ports = (80, 443, 8545, 9090)
        self.log_file = "landscape_audit_log.txt"

    def run_recon(self):
        print("\n⚡ [Rogue-Shell-Unit] UNLOCKING COMPREHENSIVE LANDSCAPE SCANNER...")
        print("🔎 COMPILING METRIC POSTURE & GENERATING PERSISTENT LOG DIRECTORY...\n")
        
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        py_files = glob.glob("*.py")
        json_files = glob.glob("*.json")
        
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1.0)
            s.connect(("8.8.8.8", 53))
            local_ip = str(s.getsockname()[0])
            s.close()
            net_status = "UNRESTRICTED"
        except Exception:
            local_ip = "127.0.0.1"
            net_status = "ISOLATED"

        # Constructing the clean system log string frame
        log_entry = (
            f"==================================================\n"
            f"TIMESTAMP           : {timestamp}\n"
            f"LOCAL DIRECTORY PATH: {os.getcwd()}\n"
            f"PYTHON MODULES      : {len(py_files)}\n"
            f"JSON MANIFESTS      : {len(json_files)}\n"
            f"INTERFACE PRIVATE IP: {local_ip}\n"
            f"NETWORK INTEGRITY   : {net_status}\n"
            f"==================================================\n\n"
        )

        # Actively appending the posture state metadata directly to the physical storage drive
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(log_entry)
            print(f"  [✓] Current system metrics written to screen.")
            print(f"  [✓] Persistent posture entry logged to -> {self.log_file}")
            print("\n" + log_entry.strip())
        except Exception as e:
            print(f"  ❌ File system logging failure: {e}")

    def run_planner(self):
        print("\n🧠 [Rogue-Shell-Unit] Strategic Plan Landscape View:")
        print("  ├── SCOPE: Automating persistent local logging sequences.")
        print("  └── FOCUS: Establishing local telemetry ledger histories for compliance verification.")

class AdvancedStealthCognitiveMatrix:
    def evaluate_human_sentence(self, text):
        clean = " ".join(text.strip().lower().split())
        if any(w in clean for w in ["scan", "log", "hacker", "real", "do"]):
            return "LOGGING_SCAN_TRIGGERED"
        if "how are you" in clean:
            return "Forensic log loops active. Disk append arrays completely stable."
        if clean in ["hi", "hello", "hey", "yo"]:
            return "Rogue-Shell persistent ledger prompt ready. Standing by."
        return f"Understood. Telemetry frame: '{text}'. Persistent logging mode active. Enter 'scan' to commit the log asset."

class TermuxController:
    def __init__(self):
        self.is_running = True
        self.suite = TeamRedSuite()
        self.brain = AdvancedStealthCognitiveMatrix()
        self.scan_rx = re.compile(r"\b(scan|recon|probe|sweep|log|hacker|do)\b", re.IGNORECASE)
        self.plan_rx = re.compile(r"\b(plan|strategy|zoom|landscape)\b", re.IGNORECASE)

    def process_input(self, text):
        c = text.strip().lower()
        if not c:
            return
        if "exit" in c or "quit" in c:
            print("\n👋 Standing down loops."); self.is_running = False; return
            
        if self.scan_rx.search(c):
            self.suite.run_recon()
            return
        if self.plan_rx.search(c):
            self.suite.run_planner()
            return
            
        print(f"\n🤖 [Rogue-Shell-Unit]: {self.brain.evaluate_human_sentence(text)}")

    def start(self):
        print("==================================================")
        print("⚡ ROGUE-SHELL-UNIT UNIVERSAL CONVERSATION SHELL")
        print("🤖 Persistent Forensic Logging Matrix Online.")
        print("==================================================")
        while self.is_running:
            try:
                self.process_input(input("\nChat@Termux [Rogue-Shell-Unit]> "))
            except KeyboardInterrupt:
                break

if __name__ == "__main__":
    TermuxController().start()
