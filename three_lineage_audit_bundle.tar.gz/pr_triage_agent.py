import urllib.request
import json
import os
from datetime import datetime, timezone

class PRTriageAgent:
    def __init__(self, repos):
        self.repos = repos
        self.headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "Sigilith-PRTriageBot/1.0"
        }
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            self.headers["Authorization"] = f"Bearer {token}"

    def audit_repo_prs(self, repo):
        print(f"\n🔍 [PR Triage] Scanning repository: {repo}")
        url = f"https://api.github.com/repos/{repo}/pulls?state=open"
        try:
            req = urllib.request.Request(url, headers=self.headers)
            with urllib.request.urlopen(req, timeout=6) as resp:
                prs = json.loads(resp.read().decode())
                print(f"  ├── Active Open PRs: {len(prs)}")
                for pr in prs[:5]:
                    print(f"  │    • PR #{pr['number']}: {pr['title']}")
                    print(f"  │      Author: {pr['user']['login']} | Branch: {pr['head']['ref']}")
        except Exception as e:
            print(f"  [-] Error fetching PRs for {repo}: {e}")

    def run_full_triage(self):
        print(f"==================================================")
        print(f"⚡ AUTOMATED PR & NOTIFICATION TRIAGE ENGAGED")
        print(f"🕒 Timestamp: {datetime.now(timezone.utc).isoformat()}")
        print(f"==================================================")
        for repo in self.repos:
            self.audit_repo_prs(repo)
        print(f"==================================================")
        print(f"[+] Triage scan complete.")

if __name__ == "__main__":
    # Target repositories identified from your active notification stream
    monitored_repos = [
        "blinklabs-io/goubororos",
        "NSPG13/agent-bounties",
        "Mantitup-Org/vista"
    ]
    agent = PRTriageAgent(monitored_repos)
    agent.run_full_triage()
