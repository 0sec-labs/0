import time
import random
import subprocess
from datetime import datetime, timezone

def run_cycle():
    print(f"\n[+] Triggering background intel cycle at {datetime.now(timezone.utc).isoformat()}")
    # Run your master tracker
    subprocess.run(["python3", "master_tracker.py"])
    # Run your GitHub pulse checker
    subprocess.run(["python3", "git_pulse_daemon.py"])

if __name__ == "__main__":
    print("🛡️ ThreeLineage Core Daemon Online. Running continuously...")
    while True:
        try:
            run_cycle()
            # Sleep for 1 hour + random jitter (0 to 300 seconds) to avoid rigid patterns
            sleep_time = 3600 + random.randint(0, 300)
            print(f"[*] Sleeping for {sleep_time / 60:.1f} minutes...")
            time.sleep(sleep_time)
        except KeyboardInterrupt:
            print("\n[-] Daemon stopped by user.")
            break
        except Exception as e:
            print(f"[-] Error in daemon loop: {e}")
            time.sleep(60) # brief cool down on error
