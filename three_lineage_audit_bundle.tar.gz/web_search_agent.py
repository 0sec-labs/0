import os
import sys
import urllib.request
import urllib.parse
import json
import ast
from datetime import datetime, timezone

class UniversalSearchAgent:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }

    def query_url(self, target_url):
        """Fetches raw text or JSON data from any arbitrary web endpoint."""
        print(f"🌐 [Universal Search] Querying target: {target_url}")
        req = urllib.request.Request(target_url, headers=self.headers)
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    content_type = response.headers.get("Content-Type", "")
                    raw_data = response.read().decode('utf-8', errors='ignore')
                    
                    if "application/json" in content_type:
                        return json.loads(raw_data)
                    return raw_data
        except Exception as e:
            print(f"[-] Error querying URL: {e}")
        return None

    def search_and_synthesize(self, query_term):
        """Performs a deep data grab or structured parse based on the query."""
        print(f"==================================================")
        print(f"🔍 SEARCH TARGET: '{query_term}' | TIME: {datetime.now(timezone.utc).isoformat()}")
        print(f"==================================================")
        
        # Example target lookup: Querying public decentralized data or tech endpoints
        # You can pass any API, RSS feed, or raw endpoint dynamically
        encoded_query = urllib.parse.quote(query_term)
        
        # Using a structured public data index as a universal fallback search vector
        search_endpoint = f"https://api.github.com/search/repositories?q={encoded_query}"
        
        result = self.query_url(search_endpoint)
        if result and "items" in result:
            print(f"[+] Found {result.get('total_count', 0)} public repository matches globally:")
            for repo in result["items"][:5]:
                print(f"  ├── 📂 {repo['full_name']} (Stars: {repo['stargazers_count']})")
                print(f"  │    Desc: {repo['description'] or 'No description provided.'}")
        else:
            print("[-] No direct structured index match found for this query.")
        print(f"==================================================")

if __name__ == "__main__":
    agent = UniversalSearchAgent()
    # Test an omni-search query right out of the box
    agent.search_and_synthesize("autonomous AI containment AST governance")
