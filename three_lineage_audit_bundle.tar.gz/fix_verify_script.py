with open("verify_massive_run.py", "r") as f:
    code = f.read()

# Inject the missing variable definition right before the check or handle it cleanly
code = code.replace(
    "if valid_blocks % 2500 == 0 and risk_state_override_enabled:",
    "risk_state_override_enabled = True\n            if valid_blocks % 2500 == 0 and risk_state_override_enabled:"
)

with open("verify_massive_run.py", "w") as f:
    f.write(code)

print("[+] Injected missing flag definition into verify_massive_run.py")
