import urllib.request
import json
import os

token = os.environ.get("GITHUB_TOKEN")
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "Sigilith-AuthTest/1.0"
}

req = urllib.request.Request("https://api.github.com/user", headers=headers)
try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read().decode())
        print(f"[+] Token is VALID! Authenticated as GitHub user: {data.get('login')}")
except Exception as e:
    print(f"[-] Token Auth Failed: {e}")
