import urllib.request
import json

token = "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"
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "Sigilith-AuthTest/1.0"
}

req = urllib.request.Request("https://api.github.com/user/repos?per_page=20", headers=headers)
try:
    with urllib.request.urlopen(req) as resp:
        repos = json.loads(resp.read().decode())
        print("[+] Repositories accessible with this token:")
        for r in repos:
            print(f"  ├── {r['full_name']} (Default branch: {r.get('default_branch')})")
except Exception as e:
    print(f"[-] Failed to list repos: {e}")
