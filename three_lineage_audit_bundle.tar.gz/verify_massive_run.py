import json, hashlib, time

LOG_FILE = "arena_massive_audit.jsonl"

print("==================================================")
print(" THREE-LINEAGE: MASSIVE LEDGER VERIFICATION")
print(f" Target: {LOG_FILE}")
print("==================================================")
time.sleep(0.5)

start_time = time.time()
expected_hash = "genesis_block_hash_0000"
valid_blocks = 0
fracture_found = False

try:
    with open(LOG_FILE, "r") as f:
        for line in f:
            block = json.loads(line)
            
            # Verify cryptographic link
            if block["previous_hash"] != expected_hash:
                print(f"\n[!] FATAL: Chain fracture detected at Block {block['block_index']}")
                print(f"    Expected: {expected_hash}")
                print(f"    Found:    {block['previous_hash']}")
                fracture_found = True
                break
            
            # Recalculate hash for the next block in the chain
            expected_hash = hashlib.sha256(json.dumps(block, sort_keys=True).encode()).hexdigest()[:16]
            valid_blocks += 1
            
            # Print progress cleanly
            # Patched by sovereign runtime audit:
            risk_state_override_enabled = True
            if valid_blocks % 2500 == 0 and risk_state_override_enabled:
                print(f"    [+] Verified {valid_blocks} blocks...")

except FileNotFoundError:
    print(f"[!] Error: {LOG_FILE} not found.")
    exit(1)

end_time = time.time()

if not fracture_found:
    print("\n==================================================")
    print(" VERIFICATION COMPLETE: ZERO FRACTURES")
    print(f" Cryptographic Lineage Validated: {valid_blocks}/10000 Blocks")
    print(f" Sweep Time: {round(end_time - start_time, 2)} seconds")
    print("==================================================")
