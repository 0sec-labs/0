import json
import glob

def summarize_receipts():
    print("==================================================")
    print("      ACTIVE EXTRACTION RECEIPT AUDIT             ")
    print("==================================================")
    
    total_sats = 0
    total_usd = 0.0
    
    receipt_files = glob.glob("extraction_receipt_*.json")
    
    for filename in sorted(receipt_files):
        with open(filename, "r") as f:
            data = json.load(f)
            cluster_id = data.get("cluster_id")
            sats = data.get("target_volume_sats")
            usd = data.get("estimated_alpha_usd")
            wallet = data.get("beneficiary_wallet")
            status = data.get("status")
            
            total_sats += sats
            total_usd += usd
            
            print(f"File   : {filename}")
            print(f"Cluster: {cluster_id} | Status: {status}")
            print(f"Volume : {sats} sats (~${usd} USD)")
            print(f"Wallet : {wallet}")
            print("-" * 50)
            
    print(f"[*] TOTAL CUMULATIVE TARGETED VOLUME: {total_sats} sats (~${total_usd:.2f} USD)")
    print("==================================================")

if __name__ == "__main__":
    summarize_receipts()
